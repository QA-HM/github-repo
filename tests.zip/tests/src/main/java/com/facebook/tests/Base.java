package com.facebook.tests;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Base {
	public WebDriver driver = null;
	public WebDriver getDriver(){
	    System.setProperty("webdriver.gecko.driver","/opt/eclipse-installer/geckodriver");
		DesiredCapabilities capabilities=DesiredCapabilities.firefox();
		//ChromeOptions options = new ChromeOptions();
		//options.addArguments("--incognito");
		driver =new FirefoxDriver(capabilities);
	    //driver =new ChromeDriver(); 
		return driver;
	}
	

}
