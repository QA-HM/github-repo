package com.facebook.tests;

import static org.testng.Assert.fail;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class TaskTwo {
	//Script Variables
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	public WebDriverWait wait;
	private Actions actions;
	private WebElement menu;
	private WebElement submenu;
	
	//Script locators
	private By us_Link=By.linkText("English (US)");
	private By fb_Login=By.id("email");
	private By fb_Pass=By.id("pass");
	private By fb_Login_Btn=By.id("loginbutton");
	private By fb_Home_Lnk=By.id("u_0_3");
	private By fb_Navi_Menu=By.xpath("//div[@id='userNavigationLabel']");
	private By logout_Link=By.xpath("//li[12]/a/span/span");	
	
  //This function responsible for initiating and opening the browser 
  @BeforeClass(alwaysRun = true)
  public void setUp()throws Exception {
	  
	  System.setProperty("webdriver.gecko.driver","/opt/eclipse-installer/geckodriver");
	  DesiredCapabilities capabilities=DesiredCapabilities.firefox();
	  driver = new FirefoxDriver(capabilities);
	  wait = new WebDriverWait(driver, 5);
	  baseUrl="/";
	  driver.navigate().to(baseUrl);
	  actions=new Actions(driver);
	  }
  
  //This function responsible for browsing to FB
  @Test
  public void browsing(){
	  baseUrl="http://www.facebook.com";
	  driver.navigate().to(baseUrl);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(us_Link));
	  this.driver.findElement(us_Link).click();
	  wait.until(ExpectedConditions.titleContains("Facebook - Log In or Sign Up"));
	  Assert.assertEquals(driver.getTitle(), "Facebook - Log In or Sign Up");
  }
  @DataProvider(name = "credentials")
  public Object[][]authentication(){
	  Object[][] arrayObject = getExcelData("/root/workspace/tests/src/main/java/testData/Creden-FB.xls","Sheet1");
	  return arrayObject;
	 
  }
  
  //This function responsible for login action and reading parameters from XLS file.
  @Test(dataProvider= "credentials",dependsOnMethods= "browsing")
  public void login_two(String fb_email,String fb_pass){
	  wait.until(ExpectedConditions.visibilityOfElementLocated(fb_Login));
	  driver.findElement(fb_Login).sendKeys(fb_email);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(fb_Pass));
	  driver.findElement(fb_Pass).sendKeys(fb_pass);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(fb_Login_Btn));
	  driver.findElement(fb_Login_Btn).click();
	  wait.until(ExpectedConditions.visibilityOfElementLocated(fb_Home_Lnk));
	  
  }
  
  /*This function should simulate the logout effect but not via the menu as I failed
  in finding a soln after trying multiple actions, I left a commented block to show
  some of my trials.
  */
  @Test(dependsOnMethods="login_two")
  public void logout_two(){
	  /*wait.until(ExpectedConditions.visibilityOfElementLocated(fb_Navi_Menu));
	  driver.findElement(fb_Navi_Menu).click();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  JavascriptExecutor executor = (JavascriptExecutor) driver;
	  executor.executeScript("arguments[0].click();", driver.findElement(logout_Link));
	  //driver.findElement(logout_Link).submit();*/	  
	  driver.navigate().to("https://developers.facebook.com/?re");
	  driver.navigate().back();
	  wait.until(ExpectedConditions.titleContains("Facebook - Log In or Sign Up"));
	  Assert.assertEquals(driver.getTitle(), "Facebook - Log In or Sign Up");
	  
  }
  
  //this function is responsible for reading of XLS files and raising proper exceptions in case of error.
  
  public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			//FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(new java.io.File(fileName));
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}
  
  @AfterClass(alwaysRun = true)
  public void tearDown(){
	  driver.quit();
	  String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
  }
}
