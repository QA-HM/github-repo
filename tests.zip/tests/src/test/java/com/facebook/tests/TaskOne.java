package com.facebook.tests;

import static org.testng.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import com.facebook.business.Deactivate;
import com.facebook.business.Home;
import com.facebook.business.Settings;
import com.facebook.business.Signup_in;
import com.facebook.page.FB_SignUp_In;
import static org.testng.Assert.assertEquals;


public class TaskOne {
	private WebDriver driver;
	private String baseUrl;
	private Base base;
	private FB_SignUp_In fb_sign_in;
	private Signup_in signup_fb;
	private Home home_fb;
	private Deactivate deactivate_fb;
	private Settings settings_fb;
	private Deactivate deact_fb;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	public WebDriverWait wait;

    @BeforeClass  
    public void setUp( )throws Exception
    {
        base = new Base();
        driver = base.getDriver();
        wait = new WebDriverWait(driver, 5);
        signup_fb = new Signup_in(driver);
        fb_sign_in = PageFactory.initElements(driver, FB_SignUp_In.class);
        baseUrl="";
        driver.get(baseUrl);
    }
    
    @Test
    public void launch_browser()
    {
    	baseUrl = "https://www.facebook.com";
    	driver.get(baseUrl);
    	signup_fb.switch_lang();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  	    wait.until(ExpectedConditions.titleContains("Facebook - Log In or Sign Up"));
  	    Assert.assertEquals(driver.getTitle(), "Facebook - Log In or Sign Up");
       
    }
    
    @Test(dependsOnMethods= {"launch_browser"}) 
    @Parameters({"FirstName","LastName","Email","Password","Month","Day","Year","Gender"}) 
    public void sign_up(String FirstName, String LastName,String Email,String Password, String Month,String Day,String Year,String Gender) 
    {
    	
    	signup_fb.signup(FirstName, LastName, Email, Password, Month, Day, Year, Gender,driver);
    	Assert.assertEquals(driver.getTitle(), "Add Friends");
    }
    
    @Test(dependsOnMethods= {"sign_up"})
    @Parameters({"deactivate_desc"})
    public void deactivate_FB(String deact_desc)
    {
    	home_fb =new  Home(driver);
    	home_fb.goto_Settings();
    	settings_fb=new Settings(driver);
    	settings_fb.goto_deactivate();
    	deact_fb= new Deactivate(driver);
    	deact_fb.deactivateAccount(deact_desc);
    	Assert.assertTrue(deact_fb.deactivate_confirm_label.isDisplayed());
    }
   
    
    @AfterClass(alwaysRun = true)
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	    
	}
    
}
