package com.facebook.business;

import org.openqa.selenium.WebDriver;
import com.facebook.page.FB_Home;
import com.facebook.page.FB_Settings;

import static org.testng.Assert.*;

public class Settings extends FB_Settings{
    
    public Settings ( WebDriver driver )
    {
        super( driver );
    }
    

public void goto_deactivate(){
	
	this.security_tab.click();
	this.deactivate_lnk.click();
	this.deactivate_menu.click();
	
  }


}
