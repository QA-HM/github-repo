package com.facebook.business;

import org.openqa.selenium.WebDriver;
import com.facebook.page.FB_Deactivate;

public class Deactivate extends FB_Deactivate{
    
    public Deactivate( WebDriver driver )
    {
        super( driver );
    }
public void deactivateAccount(String description){
	
	this.reason_options.click();
	this.reason_desc.clear();
	this.reason_desc.sendKeys(description);
	this.deactivate_btn.click();
	this.deactivate_confirm_btn.click();
	
	
  }


}
