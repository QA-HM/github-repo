package com.facebook.business;

import static org.testng.Assert.*;

import java.awt.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.facebook.page.FB_SignUp_In;

public class Signup_in extends FB_SignUp_In{
    
	public WebDriverWait wait;
	
    public Signup_in( WebDriver driver )
    {
        super( driver );
        wait = new WebDriverWait(driver, 10);

    }
    
public void switch_lang(){
	wait.until(ExpectedConditions.visibilityOf(en_link));
	this.en_link.click();
}
public void signup(String fname,String lname,String email,String password,String month,String day,String year,String gender,WebDriver driver)
		{
	wait.until(ExpectedConditions.visibilityOf(this.firstName));
    this.firstName.sendKeys(fname);
    wait.until(ExpectedConditions.visibilityOf(this.secondName));
	this.secondName.sendKeys(lname);
	wait.until(ExpectedConditions.visibilityOf(this.email));
	this.email.sendKeys(email);
	wait.until(ExpectedConditions.visibilityOf(this.email));
	this.verify_email.sendKeys(email);
	wait.until(ExpectedConditions.visibilityOf(this.passWord));
	this.passWord.sendKeys(password);
	wait.until(ExpectedConditions.visibilityOf(this.year));
	new Select(this.year).selectByVisibleText(year);
	wait.until(ExpectedConditions.visibilityOf(this.month));
	new Select(this.month).selectByValue(month);;
	wait.until(ExpectedConditions.visibilityOf(this.day));
	new Select(this.day).selectByVisibleText(day);
	/*List<WebElement> genderOptions = (List<WebElement>) this.gender;
	for (WebElement option: genderOptions){
		if (option.getText().equals(gender)){
			option.click();
		}
    }*/
	this.gender.click();
	this.signup_btn.click();
	assertEquals(this.email_confirm_text.getText(), "Confirm your email address");
  }
public void signin(String email,String password){
	
	this.email_in.clear();
	this.email_in.sendKeys(email);
	this.passWord_in.clear();
	this.passWord_in.sendKeys(password);
	this.signin_btn.click();
}


}
