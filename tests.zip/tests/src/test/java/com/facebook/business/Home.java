package com.facebook.business;

import org.openqa.selenium.WebDriver;
import com.facebook.page.FB_Home;
import static org.testng.Assert.*;

public class Home extends FB_Home{
    
    public Home ( WebDriver driver )
    {
        super( driver );
    }
    

public void goto_Settings(){
	
	this.user_menu.click();
	this.settings_lnk.click();
	
  }


}
