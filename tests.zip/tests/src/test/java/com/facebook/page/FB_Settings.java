package com.facebook.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.facebook.tests.Base;

/**
 * Unit test for simple App.
 */
public class FB_Settings extends Base{
 	public WebDriver driver;
	
	//Initializing page elements.
    public FB_Settings( WebDriver driver){
    	
        PageFactory.initElements(driver, this);
    }

    @FindBy (xpath= "//li[@id='navItem_security']/a/div[2]/div")
	public WebElement security_tab;
	
	@FindBy (xpath= "//div[@id='SettingsPage_Content']/ul/li[10]/a/span")
	public WebElement deactivate_menu;
	
	@FindBy (linkText= "Deactivate your account.")
	public WebElement deactivate_lnk;
	
	@FindBy (xpath= "//*[@id='headerArea']/div/div/div[2]/h2")
	public WebElement settings_label;
	
}
