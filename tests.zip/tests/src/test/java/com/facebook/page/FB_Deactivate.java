package com.facebook.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.facebook.tests.Base;

public class FB_Deactivate extends Base{
	public WebDriver driver;
	
	//Initializing page elements.
	public FB_Deactivate(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id= "u_jsonp_5_q")
	public WebElement reason_options;
	
	@FindBy (name= "message")
	public WebElement reason_desc;
	
	@FindBy (name= "submit")
	public WebElement deactivate_btn;
	
	@FindBy (xpath= "//button[@value='1'])[2]")
	public WebElement deactivate_confirm_btn;
	
	@FindBy (xpath= "//div[@id='u_0_0']/div/div")
	public WebElement deactivate_confirm_label;
}
