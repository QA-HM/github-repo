package com.facebook.page;

import java.util.concurrent.TimeUnit;

import javax.swing.text.html.Option;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.facebook.tests.Base;

public class FB_SignUp_In extends Base{
	
	//Initializing page elements.
	public FB_SignUp_In(WebDriver driver){
		
		PageFactory.initElements(driver, this);
	
	}
	
	@FindBy (linkText= "English (US)")
	public WebElement en_link;
	
	
	@FindBy (id= "u_0_1")
	public WebElement firstName;
	
	@FindBy (id= "u_0_3")
	public WebElement secondName;
	
	@FindBy (id= "u_0_6")
	public WebElement email;
	
	@FindBy (id= "u_0_9")
	public WebElement verify_email;
	
	@FindBy (id= "u_0_b")
	public WebElement passWord;
	
	@FindBy (xpath= "//*[@id='month']")
	public WebElement month;
	
	@FindBy (xpath= "//*[@id='day']")
	public WebElement day;
	
	@FindBy (xpath= "//*[@id='year']")
	public WebElement year;
	
	@FindBy (id= "u_0_e")
	public WebElement gender;
	
	@FindBy (id= "u_0_j")
	public WebElement signup_btn;
	
	@FindBy (id= "email")
	public WebElement email_in;
	
	@FindBy (id= "pass")
	public WebElement passWord_in;
	
	@FindBy (id= "u_0_m")
	public WebElement signin_btn;
	
	@FindBy (xpath="//*[@id='confirm_center']/div/div[1]/div/div[2]/h2")
	public WebElement email_confirm_text;
	
	public boolean isElementPresent(String id, WebDriver driver) {
		boolean present;
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		present = driver.findElements( By.id(id) ).size() != 0;
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		
		return present;
	}

}
