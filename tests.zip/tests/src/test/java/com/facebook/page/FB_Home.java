package com.facebook.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.facebook.tests.Base;

public class FB_Home extends Base{
	
	//Initializing page elements.
	public FB_Home(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id= "userNavigationLabel")
	public WebElement user_menu;
	
	@FindBy (xpath= "//div[@id='BLUE_BAR_ID_DO_NOT_USE']/div/div/div/div/div/ul/li[11]/a/span/span")
	public WebElement settings_lnk;
	
	@FindBy (id= "checkpointSubmitButton")
	public WebElement checkout_btn;
	
	@FindBy (xpath= "//*[@id='content']/div/div/div/div/div[2]/h2")
	public WebElement sign_up_text;
}
